﻿using System.Collections.Generic;
using System.IO;
using System.PatientData.Exception;

namespace System.ExportPatientData.Impl
{
    /// <summary>
    /// API for exporting to file.
    /// </summary>
    public class FileExport : ExportAbstract
    {
        protected override void Export(List<string> patientData)
        {
            try
            {
                using (var stream = new StreamWriter(@"test.txt"))
                {
                    foreach (string value in patientData)
                    {
                        stream.WriteLine(value);
                    }

                }
            }
            catch (UnauthorizedAccessException ex)
            {
                throw new PatientDataException(ex);
            }
            catch (ArgumentNullException ex)
            {
                throw new PatientDataException(ex);
            }
            catch (ArgumentException ex)
            {
                throw new PatientDataException(ex);
            }           
            catch (DirectoryNotFoundException ex)
            {
                throw new PatientDataException(ex);
            }
            catch (PathTooLongException ex)
            {
                throw new PatientDataException(ex);
            }
            catch (IOException ex)
            {
                throw new PatientDataException(ex);
            }
            catch (ObjectDisposedException ex)
            {
                throw new PatientDataException(ex);
            }

        }
    }
}
