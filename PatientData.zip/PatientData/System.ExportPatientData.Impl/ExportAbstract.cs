﻿using System.Collections.Generic;
using System.PatientData.Exception;

namespace System.ExportPatientData.Impl
{
    /// <summary>
    /// Base Abtract exporter.
    /// </summary>
    public abstract class ExportAbstract : IExport
    {
        public bool ExportData(List<string> patientData)
        {
            try
            {
                //Sort the patient data.
                patientData.Sort(StringComparer.InvariantCulture);

                Export(patientData);
            }
            catch (PatientDataException)
            {
                return false;
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        protected abstract void Export(List<string> patientData);

    }
}
