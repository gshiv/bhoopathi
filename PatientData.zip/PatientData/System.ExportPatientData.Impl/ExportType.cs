﻿namespace System.ExportPatientData.Impl
{
    /// <summary>
    ///  Export types avaialable for systems.
    /// </summary>
    public enum ExportType
    {
        File,

        Printer,

        WebInterface,

        Other
    }
}
