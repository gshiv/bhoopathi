﻿using System.Collections.Generic;

namespace System.ExportPatientData.Impl
{
    /// <summary>
    /// API to export data to printer.
    /// </summary>
    public class PrinterExport : ExportAbstract
    {     

        //TODO once funcationality is available
        protected override void Export(List<string> patientData)
        {
            throw new NotImplementedException();
        }
    }
}
