﻿namespace System.PatientData.Exception
{
    public class PatientDataException: ApplicationException
    {
        public PatientDataException(System.Exception exception)
        {
         //TODO Add logging       
        }

        public PatientDataException(string exception)
        {
            //TODO Add logging       
        }
    }
}
