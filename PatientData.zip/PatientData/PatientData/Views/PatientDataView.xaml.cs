﻿using PatientData.ViewModels;
using System;
using System.Collections.Generic;
using System.ExportPatientData.Impl;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PatientData.Views
{
    /// <summary>
    /// Interaction logic for PatientDataView.xaml
    /// </summary>
    public partial class PatientDataView : Window
    {
        public PatientDataView()
        {
            InitializeComponent();
        }
    }
}
