﻿using PatientData.ViewModels;
using PatientData.Views;
using System;
using System.Data.Factory.Impl;
using System.ExportPatientData.Impl;
using System.PatientData.Exception;
using System.Windows;
using Unity;

namespace PatientData
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            try
            {
                var unityContainer = new UnityContainer();

                //Register the IExportFactory to its implemenation.
                unityContainer.RegisterType<IExportFactory, ExportFactory>();

                //Unoity container crates the object of PatientDataViewModel
                var patientDataViewModel = unityContainer.Resolve<PatientDataViewModel>();

                //Set the data context of PatientDataView and show thw window.
                var window = new PatientDataView { DataContext = patientDataViewModel };
                window.Show();
            }
            catch(Exception)
            {
                var errorWindow = new Error();
                errorWindow.Show();
            }
            
        }
    }
}
