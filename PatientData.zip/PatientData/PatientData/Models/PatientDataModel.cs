﻿namespace PatientData.Models
{
    public class PatientDataModel
    {
        public string PatientData1 { get; set; }
        public string PatientData2 { get; set; }
        public string PatientData3 { get; set; }
    }
}
