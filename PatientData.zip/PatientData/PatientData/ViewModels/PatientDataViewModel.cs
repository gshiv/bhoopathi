﻿using PatientData.Models;
using System.Collections.Generic;
using System.Data.Factory.Impl;
using System.ExportPatientData.Impl;
using System.Linq;

namespace PatientData.ViewModels
{
    public class PatientDataViewModel : AbstractBaseViewModel
    {
        private readonly IExportFactory myExportFactory;
        private ExportType myExportType;
        private string myErrorMessage;
        private IDictionary<string, string> myPropertiesErrorMapper = new Dictionary<string, string>
        {
            {nameof(PatientData1), string.Empty },
            {nameof(PatientData2), string.Empty },
            {nameof(PatientData3), string.Empty },
        };

        public string ErrorMessage
        {
            get
            {
                return myErrorMessage;
            }
            set
            {
                myErrorMessage = value;
                OnPropertyChanged(nameof(ErrorMessage));
            }
        }

        //use to bind to gthe UI once more exporting options are supported.
        public ExportType ExportType
        {
            get
            {
                return myExportType;
            }
            set
            {
                myExportType = ExportType;
                OnPropertyChanged(nameof(ExportType));
            }
        }

        public PatientDataViewModel(IExportFactory exportFactory) : base()
        {
            myExportFactory = exportFactory;
        }

        public override bool CanExecute(object parameter)
        {
            if (myPropertiesErrorMapper.Values.Any(x => x != string.Empty))
            {
                return false;
            }
            return true;
        }

        public override void Execute(object parameter)
        {
            var patientDataValues = new List<string>();

            //use reflection to get the properties of strimg from patient data model.
            foreach (var patientData in typeof(PatientDataModel).GetProperties().Where(x=>x.PropertyType == typeof(string)))
            {
                patientDataValues.Add((string)patientData.GetValue(PatientDataModel));
            }

            var exporter = myExportFactory.Create(ExportType);
            var operationSucessfull = exporter.ExportData(patientDataValues);

            if (operationSucessfull)
            {
                PatientData1 = null;
                PatientData2 = null;
                PatientData3 = null;
                myPropertiesErrorMapper.Clear();
                ErrorMessage = "Operation sucessfull";
            }
            else
            {
                ErrorMessage = "Error processing data.";
            }

        }

        public override string this[string columnName]
        {
            get
            {
                if (columnName.Equals(nameof(PatientData1)))
                {
                    if (!ValidateInput(PatientData1))
                    {
                        ErrorMessage = "PatientData1 should have 3 precision and value should not be null.";

                        myPropertiesErrorMapper[nameof(PatientData1)] = ErrorMessage;

                    }
                    else
                    {
                        ErrorMessage = string.Empty;
                        myPropertiesErrorMapper[nameof(PatientData1)] = string.Empty;
                    }
                }

                if (columnName.Equals(nameof(PatientData2)))
                {
                    if (!ValidateInput(PatientData2))
                    {
                        ErrorMessage = "PatientData2 should have 3 precision and value should not be null.";
                        myPropertiesErrorMapper[nameof(PatientData2)] = ErrorMessage;
                    }
                    else
                    {
                        ErrorMessage = string.Empty;
                        myPropertiesErrorMapper[nameof(PatientData2)] = string.Empty;
                    }
                }
                if (columnName.Equals(nameof(PatientData3)))
                {
                    if (!int.TryParse(PatientData3, out _))
                    {
                        ErrorMessage = "Enter integer data for PatientData3.";
                        myPropertiesErrorMapper[nameof(PatientData3)] = ErrorMessage;
                    }
                    else
                    {
                        ErrorMessage = string.Empty;
                        myPropertiesErrorMapper[nameof(PatientData3)] = string.Empty;
                    }
                }

                return ErrorMessage;
            }
        }

        private bool ValidateInput(string data)
        {

            if (data == null || !data.Contains('.'))
            {
                return false;
            }

            var precionValues = data.Split('.').Last();

            if (precionValues.Length != 3)
            {

                return false;
            }
            return true;
        }
    }

}
