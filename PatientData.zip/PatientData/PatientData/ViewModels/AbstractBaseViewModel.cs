﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using JetBrains.Annotations;
using PatientData.Command;
using PatientData.Models;

namespace PatientData.ViewModels
{
    public abstract class AbstractBaseViewModel : INotifyPropertyChanged, IDataErrorInfo
    {
        internal PatientDataModel PatientDataModel = new PatientDataModel();

        public event PropertyChangedEventHandler PropertyChanged;

        public abstract bool CanExecute(object parameter);
        public RelayCommand Command { get; set; }
        public abstract void Execute(object parameter);
        protected AbstractBaseViewModel()
        {
            Command = new RelayCommand(CanExecute, Execute);
        }

        //public PatientDataModel PatientData
        //{
        //    get => myPatientDataModel;
        //    set
        //    {
        //        myPatientDataModel = value;
        //        OnPropertyChanged(nameof(PatientData));
        //    }
        //}

        public string PatientData1
        {
            get => PatientDataModel.PatientData1;
            set
            {
                PatientDataModel.PatientData1 = value;
                OnPropertyChanged(nameof(PatientData1));
            }
        }
        public string PatientData2
        {
            get => PatientDataModel.PatientData2;
            set
            {
                PatientDataModel.PatientData2 = value;
                OnPropertyChanged(nameof(PatientData2));
            }
        }

        public string PatientData3
        {
            get => PatientDataModel.PatientData3;
            set
            {
                PatientDataModel.PatientData3 = value;
                OnPropertyChanged(nameof(PatientData3));
            }
        }



        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public virtual string this[string columnName] => string.Empty;

        public string Error { get; }
    }
}
