﻿using System;
using System.Windows.Input;


namespace PatientData.Command
{
    public class RelayCommand : ICommand
    {
        private readonly Func<object, bool> myCanExecute;
        private readonly Action<object> myExecute;

        public RelayCommand(Func<object, bool> canExecute, Action<object> execute)
        {
            myCanExecute = canExecute;
            myExecute = execute;
        }

        event EventHandler ICommand.CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;

            remove => CommandManager.RequerySuggested -= value;
        }

        public bool CanExecute(object parameter)
        {
            return myCanExecute(parameter);
        }
        public void Execute(object parameter)
        {
            myExecute(parameter);
        }     

    }
}
