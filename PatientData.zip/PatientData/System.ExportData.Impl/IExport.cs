﻿namespace System.ExportData.Impl
{
    /// <summary>
    ///  API to export PatientData to External resources
    /// </summary>
    public interface IExport
    {
        /// <summary>
        /// Export data to external resources
        /// </summary>
        /// <returns> true if data exported successfully.</returns>
        bool ExportData(PatientDataModel patientDataModel);
    }
}
