﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.ExportData.Impl
{
    public class FileExport : IExport
    {
        public bool ExportData()
        {
            throw new NotImplementedException();
        }
    }
}
