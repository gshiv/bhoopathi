﻿using System.Collections.Generic;
using System.ExportPatientData.Impl;
using System.PatientData.Exception;

namespace System.Data.Factory.Impl
{
    public class ExportFactory : IExportFactory
    {
        private readonly IDictionary<ExportType, Type> myExportTypeMapper = new Dictionary<ExportType, Type>
        {
            {ExportType.File, typeof(FileExport) },
            {ExportType.Printer, typeof(PrinterExport) }
        };

        public IExport Create(ExportType exportType)
        {
            if(myExportTypeMapper.TryGetValue(exportType, out Type type))
            {
                return (IExport)Activator.CreateInstance(type);
            }

            throw new PatientDataException($"Invalid ExportType {exportType}");
        }
    }
}
