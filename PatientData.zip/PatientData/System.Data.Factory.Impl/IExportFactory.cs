﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.ExportPatientData.Impl;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace System.Data.Factory.Impl
{
    public interface IExportFactory
    {
        IExport Create(ExportType exportType);
    }
}
